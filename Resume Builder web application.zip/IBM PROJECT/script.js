 function addEducation(){
   let newarea=document.createElement('textarea');
   newarea.classList.add('education');
   newarea.setAttribute('rows',3);
   newarea.setAttribute('cols',52);
   let edob=document.getElementById("ed");
   let wAddbuttonob=document.getElementById("wAddbutton");
    edob.insertBefore(newarea,wAddbutton);
    newarea.setAttribute('placeholder','Enter here');
}
function Addworkexp(){
    let newarea=document.createElement('textarea');
    newarea.classList.add('workexp');
    newarea.setAttribute('rows',3);
    newarea.setAttribute('cols',52);
    let wob=document.getElementById("w");
    let weob=document.getElementById("we");
     wob.insertBefore(newarea,we);
     newarea.setAttribute('placeholder','Enter here');
}
function generateCV(){
  let name=document.getElementById("name").value;
  let name2=document.getElementById("name2");
  name2.innerHTML=name;
  //About me
  document.getElementById("about1").innerHTML=document.getElementById("about2").value;
  //phone
  let phone1=document.getElementById("phone1").value;
  let phone2=document.getElementById("phone2");
  phone2.innerHTML=phone1;
  //email
  let email1=document.getElementById("email1").value;
  let email2=document.getElementById("email2");
  email2.innerHTML=email1;
  //address
  let address1=document.getElementById("address1").value;
  let address2=document.getElementById("address2");
  address2.innerHTML=address1;
  //about
  let about1=document.getElementById("about1").value;
  let about2=document.getElementById("about2");
  about2.innerHTML=about1;
  //intrest1
  let intrest3=document.getElementById("intrest3").value;
  let intrest4=document.getElementById("intrest4");
  intrest4.innerHTML=intrest3;
  //intrest2
  let intrest5=document.getElementById("intrest5").value;
  let intrest6=document.getElementById("intrest6");
  intrest6.innerHTML=intrest5;
  //intrest3
  let intrest1=document.getElementById("intrest1").value;
  let intrest2=document.getElementById("intrest2");
  intrest2.innerHTML=intrest1;
  //link

  let link1=document.getElementById("link1").value;
  let link2=document.getElementById("link2");
  link2.innerHTML=link1;
  //project
  let area1=document.getElementById("area1").value;
  let area2=document.getElementById("area2");
  area2.innerHTML=area1;
  //skills
  let skill1=document.getElementById("skill1").value;
  let skill4=document.getElementById("skill4");
  skill4.innerHTML=skill1;
  //image
  let file=document.getElementById("image2").files[0];
  console.log(file);
  let reader=new FileReader();
  reader.readAsDataURL(file);
  console.log(reader.result);
  reader.onloadend=function(){
    document.getElementById("imgtemp").src=reader.result;
  }

  
  //work experience
  let wes=document.getElementsByClassName("workexp");
  let str="";
  for(let e of wes){
    str=str+`<li> ${e.value} </li>`;
  }
  document.getElementById("wet").innerHTML=str;
  //eduaction
  let pes=document.getElementsByClassName("education");
  let str1="";
  for(let e of pes){
    str1=str1+`<li> ${e.value} </li>`;
  }
  document.getElementById("edv").innerHTML=str1;
  document.getElementById('main').style.display='none';
  document.getElementById('template').style.display='block';

}
function printCV(){
  window.print();
}

